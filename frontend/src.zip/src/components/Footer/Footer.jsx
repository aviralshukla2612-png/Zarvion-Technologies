import React from 'react';
import { Link } from 'react-router-dom';
import { FiTwitter, FiLinkedin, FiGithub, FiInstagram } from 'react-icons/fi';
import logo from '../../assets/images/logo.jpeg';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer-section">
      <div className="footer-wrap">
        <div className="footer-grid">
          <div className="footer-brand">
            <Link to="/" className="footer-logo">
              <img src={logo} alt="Zarvion Technologies logo" />
              <span className="brand-name">Zarvion<em>Technologies</em></span>
            </Link>
            <p className="footer-desc">
              Empowering ambitious professionals with world-class career opportunities and cutting-edge IT solutions.
            </p>
            <div className="social-links">
              <a href="#" aria-label="Twitter"><FiTwitter /></a>
              <a href="#" aria-label="LinkedIn"><FiLinkedin /></a>
              <a href="#" aria-label="GitHub"><FiGithub /></a>
              <a href="#" aria-label="Instagram"><FiInstagram /></a>
            </div>
          </div>
          
          <div className="footer-links">
            <h4>Company</h4>
            <ul>
              <li><a href="#about">About Us</a></li>
              <li><a href="#services">Our Services</a></li>
              <li><a href="#demanded">Careers</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </div>
          
          <div className="footer-links">
            <h4>Resources</h4>
            <ul>
              <li><a href="#">Blog</a></li>
              <li><a href="#">Case Studies</a></li>
              <li><a href="#">Documentation</a></li>
              <li><a href="#">Help Center</a></li>
            </ul>
          </div>
          
          <div className="footer-links">
            <h4>Legal</h4>
            <ul>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="#">Terms of Service</a></li>
              <li><a href="#">Cookie Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>&copy; {new Date().getFullYear()} Zarvion Technologies. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
