import React from 'react';
import './Testimonials.css';

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      name: "Sarah Jenkins",
      role: "Lead Software Engineer",
      company: "TechNova",
      text: "Zarvion Technologies completely transformed our development process. Their expertise and attention to detail are unmatched in the industry."
    },
    {
      id: 2,
      name: "Michael Chen",
      role: "CTO",
      company: "Innovate AI",
      text: "Working with Zarvion was a game-changer. They delivered scalable solutions that exceeded our expectations and drove our growth."
    },
    {
      id: 3,
      name: "Elena Rodriguez",
      role: "Product Manager",
      company: "Global Nexus",
      text: "The team's dedication to our success was evident from day one. They are true partners who genuinely care about delivering excellence."
    }
  ];

  return (
    <section className="testimonials-section">
      <div className="testimonials-wrap">
        <header className="testimonials-header">
          <span className="testimonials-badge">SUCCESS STORIES</span>
          <h2 className="testimonials-heading">What Our <span>Clients</span> Say</h2>
        </header>

        <div className="testimonials-grid">
          {testimonials.map(t => (
            <div className="testimonial-card" key={t.id}>
              <div className="quote-mark">"</div>
              <p className="testimonial-text">{t.text}</p>
              <div className="testimonial-author">
                <div className="author-avatar">{t.name.charAt(0)}</div>
                <div className="author-info">
                  <h4>{t.name}</h4>
                  <p>{t.role}, {t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
