import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../../assets/images/logo.jpeg';
import './Navbar.css';

const Navbar = () => {
  const [filled, setFilled] = useState(false);
  const [activeSection, setActiveSection] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setFilled(window.scrollY > 10);

      // Scrollspy logic
      const sections = ['about', 'services', 'demanded', 'contact'];
      let current = '';
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= window.innerHeight / 2 && rect.bottom >= window.innerHeight / 2) {
            current = section;
          }
        }
      }
      setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleGetStarted = (e) => {
    e.preventDefault();
    navigate('/get-started');
  };

  return (
    <>
      {/* NAVBAR */}
      <nav className={`navbar ${filled ? 'filled' : ''}`} aria-label="Primary">
        <Link to="/" className="brand" aria-label="Zarvion Technologies home">
          <img src={logo} alt="Zarvion Technologies logo" />
          <span className="brand-name">Zarvion<em>Technologies</em></span>
        </Link>

        <ul className="nav-links">
          <li><Link to="/" className={!activeSection ? 'active' : ''}>Home</Link></li>
          <li><a href="/about" className={activeSection === 'about' ? 'active' : ''}>About</a></li>
          <li><a href="/service" className={activeSection === 'services' ? 'active' : ''}>Services</a></li>
          <li><a href="/demand" className={activeSection === 'demanded' ? 'active' : ''}>Demand IT Roles</a></li>
          <li><a href="/contact" className={activeSection === 'contact' ? 'active' : ''}>Contact</a></li>
        </ul>

        <Link to="/get-started" className="nav-btn" onClick={handleGetStarted}>
          Get Started
        </Link>
      </nav>
    </>
  );
};

export default Navbar;