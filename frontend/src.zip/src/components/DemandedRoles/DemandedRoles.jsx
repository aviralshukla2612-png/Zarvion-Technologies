import React, { useLayoutEffect, useRef, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ROLES } from './roles';
import './DemandedRoles.css';

gsap.registerPlugin(ScrollTrigger);

const DemandedRoles = () => {
  const navigate = useNavigate();
  
  // Refs
  const sectionRef = useRef(null);
  const trackRef = useRef(null);
  const viewportRef = useRef(null);
  const stageRef = useRef(null);
  const cardRefs = useRef([]);
  
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const activeIndexRef = useRef(0);
  const isInitializedRef = useRef(false);

  // Handle resize
  useEffect(() => {
    let timer;
    const handleResize = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        const mobile = window.innerWidth <= 768;
        setIsMobile(mobile);
        ScrollTrigger.refresh();
      }, 200);
    };
    window.addEventListener('resize', handleResize);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const handleCardClick = (slug) => {
    navigate(`/roles/${slug}`);
  };

  useLayoutEffect(() => {
    // ============================================================
    // STEP 1: DEBUG - Check if component is mounting
    // ============================================================
    console.log('===== DemandedRoles Init =====');
    console.log('sectionRef:', sectionRef.current);
    console.log('trackRef:', trackRef.current);
    console.log('viewportRef:', viewportRef.current);
    console.log('stageRef:', stageRef.current);
    console.log('cards length:', cardRefs.current.length);

    // Check refs
    if (!trackRef.current) console.error('❌ trackRef is NULL');
    if (!viewportRef.current) console.error('❌ viewportRef is NULL');
    if (!stageRef.current) console.error('❌ stageRef is NULL');
    if (!sectionRef.current) console.error('❌ sectionRef is NULL');
    if (cardRefs.current.length === 0) console.error('❌ No cards found');

    const track = trackRef.current;
    const viewport = viewportRef.current;
    const stage = stageRef.current;
    const cards = cardRefs.current;

    if (!track || !viewport || !stage || cards.length === 0) {
      console.error('❌ Missing required refs, skipping animation');
      return;
    }

    // ============================================================
    // STEP 2: DEBUG - Check DOM measurements
    // ============================================================
    console.log('track height:', track.offsetHeight);
    console.log('viewport height:', viewport.offsetHeight);
    console.log('stage width:', stage.scrollWidth);
    console.log('window width:', window.innerWidth);
    console.log('first card width:', cards[0]?.offsetWidth);
    console.log('isMobile:', isMobile);

    // ============================================================
    // MOBILE - Stack vertically
    // ============================================================
    if (isMobile) {
      console.log('📱 Mobile mode - stacking vertically');
      stage.style.transform = 'none';
      track.style.height = 'auto';
      cards.forEach((card, i) => {
        card.style.opacity = '1';
        card.style.transform = 'none';
        card.style.zIndex = '1';
        card.classList.toggle('active', i === 0);
      });
      return;
    }

    // ============================================================
    // DESKTOP - Setup animation
    // ============================================================
    console.log('💻 Desktop mode - setting up animation');

    // Clean up previous animations
    if (window._gsapTimeline) {
      window._gsapTimeline.kill();
      window._gsapTimeline = null;
    }
    if (window._scrollTrigger) {
      window._scrollTrigger.kill();
      window._scrollTrigger = null;
    }

    // Measure cards
    const cardWidth = cards[0].offsetWidth || 400;
    const gap = 32;
    const step = cardWidth + gap;
    const totalCards = ROLES.length;
    const totalWidth = step * (totalCards - 1);
    const viewportHeight = viewport.clientHeight || window.innerHeight;

    console.log('cardWidth:', cardWidth);
    console.log('step:', step);
    console.log('totalCards:', totalCards);
    console.log('totalWidth:', totalWidth);
    console.log('viewportHeight:', viewportHeight);

    // Set track height
    track.style.height = `${viewportHeight + totalWidth}px`;
    console.log('track height set to:', track.style.height);

    // Reset cards - GSAP will control these
    cards.forEach((card, i) => {
      gsap.set(card, {
        scale: i === 0 ? 1 : 0.8,
        opacity: i === 0 ? 1 : 0.25,
        zIndex: i === 0 ? 3 : 1,
        force3D: true
      });
      card.classList.toggle('active', i === 0);
    });

    // ============================================================
    // CREATE ANIMATION
    // ============================================================
    console.log('🎬 Creating GSAP timeline...');

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: track,
        start: "top top",
        end: `+=${totalWidth}`,
        scrub: 1.2,
        pin: true,
        invalidateOnRefresh: true,
        anticipatePin: 1,
        fastScrollEnd: true,
        onUpdate: (self) => {
          // Debug - uncomment to see progress
          // console.log('📊 progress:', self.progress);
          
          const progress = self.progress;
          const rawIndex = progress * (totalCards - 1);
          const roundedIndex = Math.round(rawIndex);
          
          // Update active index
          if (roundedIndex !== activeIndexRef.current) {
            activeIndexRef.current = roundedIndex;
            setActiveIndex(roundedIndex);
          }
          
          // Update cards
          cards.forEach((card, i) => {
            const distance = Math.abs(i - rawIndex);
            let scale, opacity, zIndex;
            
            if (distance <= 0.5) {
              scale = 1;
              opacity = 1;
              zIndex = 3;
            } else if (distance <= 1.5) {
              const t = (distance - 0.5) / 1.0;
              scale = 1 - 0.15 * Math.min(t, 1);
              opacity = 1 - 0.5 * Math.min(t, 1);
              zIndex = 2;
            } else {
              scale = 0.8;
              opacity = 0.25;
              zIndex = 1;
            }
            
            gsap.set(card, {
              scale: scale,
              opacity: opacity,
              zIndex: zIndex,
              force3D: true
            });
            
            card.classList.toggle('active', i === roundedIndex);
          });
        },
        onRefresh: (self) => {
          console.log('🔄 ScrollTrigger refreshed');
        }
      }
    });

    // Store references
    window._gsapTimeline = tl;
    window._scrollTrigger = tl.scrollTrigger;

    // ============================================================
    // STEP 3: DEBUG - Check ScrollTrigger creation
    // ============================================================
    console.log('Timeline created:', tl);
    console.log('ScrollTrigger:', tl.scrollTrigger);
    if (!tl.scrollTrigger) {
      console.error('❌ ScrollTrigger not created!');
    }

    // ============================================================
    // HORIZONTAL SLIDE
    // ============================================================
    tl.fromTo(stage, 
      { x: 0 },
      { 
        x: -totalWidth,
        ease: "none",
        force3D: true
      },
      0
    );

    console.log('✅ Animation setup complete');
    console.log('Stage transform set to:', stage.style.transform);

    // ============================================================
    // HOVER EFFECTS
    // ============================================================
    cards.forEach((card) => {
      const image = card.querySelector('.card-image');
      if (!image) return;
      
      const onHover = () => {
        if (card.classList.contains('active')) {
          gsap.to(card, {
            scale: 1.03,
            duration: 0.4,
            ease: "power2.out",
            force3D: true,
            overwrite: 'auto'
          });
        }
      };
      
      const onLeave = () => {
        if (card.classList.contains('active')) {
          gsap.to(card, {
            scale: 1,
            duration: 0.4,
            ease: "power2.out",
            force3D: true,
            overwrite: 'auto'
          });
        }
      };
      
      image.addEventListener('mouseenter', onHover);
      image.addEventListener('mouseleave', onLeave);
      
      card._cleanup = () => {
        image.removeEventListener('mouseenter', onHover);
        image.removeEventListener('mouseleave', onLeave);
      };
    });

    // ============================================================
    // STEP 4: Check if onUpdate runs
    // ============================================================
    console.log('🔄 Initial refresh...');
    ScrollTrigger.refresh();

    // Double check after a moment
    setTimeout(() => {
      console.log('⏰ After 500ms check:');
      console.log('track height:', track.offsetHeight);
      console.log('viewport height:', viewport.offsetHeight);
      console.log('stage transform:', stage.style.transform);
      console.log('ScrollTrigger exists:', !!window._scrollTrigger);
    }, 500);

    // ============================================================
    // CLEANUP
    // ============================================================
    return () => {
      console.log('🧹 Cleaning up...');
      
      cards.forEach((card) => {
        if (card._cleanup) {
          card._cleanup();
          delete card._cleanup;
        }
      });
      
      if (window._gsapTimeline) {
        window._gsapTimeline.kill();
        window._gsapTimeline = null;
      }
      if (window._scrollTrigger) {
        window._scrollTrigger.kill();
        window._scrollTrigger = null;
      }
      
      ScrollTrigger.getAll().forEach(st => {
        if (st.vars.trigger === track) {
          st.kill();
        }
      });
    };
  }, [isMobile]);

  return (
    <section className="roles-section" ref={sectionRef}>
      <header className="roles-intro">
        <span className="roles-badge">
          <span className="roles-badge-dot" aria-hidden="true"></span>
          HOT CAREER OPPORTUNITIES
        </span>
        <h2 className="roles-heading">Most Demanded IT Roles</h2>
        <p className="roles-desc">
          Explore today's fastest-growing technology careers and discover the skills,
          opportunities, and career paths that leading companies are actively hiring for.
        </p>
      </header>

      <div className="pin-track" ref={trackRef}>
        <div className="pin-viewport" ref={viewportRef}>
          <div className="card-stage" ref={stageRef}>
            {ROLES.map((role, index) => (
              <article
                key={role.slug}
                ref={(el) => (cardRefs.current[index] = el)}
                className="role-card"
                data-index={index}
              >
                <div
                  className="card-image"
                  onClick={() => handleCardClick(role.slug)}
                  role="link"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleCardClick(role.slug);
                    }
                  }}
                  aria-label={`View ${role.title} details`}
                >
                  <img 
                    src={role.img} 
                    alt={role.title} 
                    loading="eager"
                    decoding="sync"
                  />
                  <div className="image-overlay" />
                  <div className="image-glow" />
                  <div className="image-hover-veil" />
                  <h3 className="image-title">{role.title}</h3>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default DemandedRoles;