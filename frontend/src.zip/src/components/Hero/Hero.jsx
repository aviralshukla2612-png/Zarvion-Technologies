import React, { useEffect, useRef } from 'react';
import './Hero.css';

const Hero = () => {
  const canvasRef = useRef(null);
  const typedHeadRef = useRef(null);
  const cursorRef = useRef(null);

  // Typing effect
  useEffect(() => {
    const el = typedHeadRef.current;
    const cursor = cursorRef.current;
    if (!el || !cursor) return;

    const line1 = 'EMPOWERING AMBITIOUS PROFESSIONALS WITH';
    const phrases = [
      'GLOBAL JOB PLACEMENTS.',
      'TOP IT CAREER SOLUTIONS.',
      'PREMIUM RECRUITMENT SERVICES.',
      'CAREER GROWTH WITHOUT LIMITS.',
      'YOUR DREAM JOB STARTS HERE.',
      'CONNECTING TALENT GLOBALLY.',
      'FUTURE-READY CAREERS.',
      'HIGH-PAYING IT OPPORTUNITIES.',
      'BUILD YOUR GLOBAL CAREER.'
    ];

    const CHAR_DELAY = 28;
    const DELETE_DELAY = 18;
    const HOLD_TIME = 1600;
    const GAP_TIME = 300;
    const START_DELAY = 500;

    let c1 = 0;
    let pIdx = 0;
    let c2 = 0;
    let deleting = false;
    let timeoutId;

    const renderText = (line1Part, line2Part) => {
      el.innerHTML = line1Part + (line1Part ? '<br>' : '') + '<span class="accent-line">' + line2Part + '</span>';
      el.appendChild(cursor);
    };

    const typeLine1 = () => {
      if (c1 <= line1.length) {
        renderText(line1.slice(0, c1), '');
        c1++;
        timeoutId = setTimeout(typeLine1, CHAR_DELAY);
      } else {
        timeoutId = setTimeout(loopStep, GAP_TIME);
      }
    };

    const loopStep = () => {
      const phrase = phrases[pIdx];

      if (!deleting) {
        c2++;
        renderText(line1, phrase.slice(0, c2));
        if (c2 === phrase.length) {
          deleting = true;
          timeoutId = setTimeout(loopStep, HOLD_TIME);
        } else {
          timeoutId = setTimeout(loopStep, CHAR_DELAY);
        }
      } else {
        c2--;
        renderText(line1, phrase.slice(0, c2));
        if (c2 === 0) {
          deleting = false;
          pIdx = (pIdx + 1) % phrases.length;
          timeoutId = setTimeout(loopStep, GAP_TIME);
        } else {
          timeoutId = setTimeout(loopStep, DELETE_DELAY);
        }
      }
    };

    timeoutId = setTimeout(typeLine1, START_DELAY);

    return () => clearTimeout(timeoutId);
  }, []);

  // Canvas animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let W, H;
    let animationFrameId;

    const resize = () => {
      W = canvas.width = canvas.offsetWidth || canvas.parentElement.clientWidth;
      H = canvas.height = canvas.offsetHeight || canvas.parentElement.clientHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    let elapsed = 0;
    let lastT = performance.now();

    const HY_FRAC = 0.44;
    const TRACK_HW = 0.42;
    const CURVE_MAX = 0.30;
    const CURVE_PER = 14;

    const trackPt = (pos, lateralFrac) => {
      const sqP = Math.sqrt(Math.max(0, pos));
      const horizY = H * HY_FRAC;
      const y = horizY + (H - horizY) * sqP;

      const depth = 1 - sqP;
      const curveAmt = W * CURVE_MAX * Math.sin((elapsed * Math.PI * 2) / CURVE_PER);
      const cx = W * 0.5 + curveAmt * depth * depth;

      const hw = W * TRACK_HW * sqP;

      return { x: cx + lateralFrac * hw, y };
    };

    const vpPos = () => {
      const curveAmt = W * CURVE_MAX * Math.sin((elapsed * Math.PI * 2) / CURVE_PER);
      return { x: W * 0.5 + curveAmt, y: H * HY_FRAC };
    };

    const drawRails = () => {
      const STEPS = 120;
      const SIDES = [-0.82, 0.82];

      SIDES.forEach(side => {
        const pts = [];
        for (let i = 0; i <= STEPS; i++) {
          const pos = i / STEPS;
          pts.push(trackPt(pos, side));
        }

        // 1 — Wide diffuse glow
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i <= STEPS; i++) ctx.lineTo(pts[i].x, pts[i].y);
        ctx.strokeStyle = 'rgba(40,120,255,0.09)';
        ctx.lineWidth = 26;
        ctx.lineCap = 'butt';
        ctx.shadowColor = 'rgba(60,150,255,0.55)';
        ctx.shadowBlur = 40;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // 2 — Medium glow
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i <= STEPS; i++) ctx.lineTo(pts[i].x, pts[i].y);
        ctx.strokeStyle = 'rgba(80,170,255,0.18)';
        ctx.lineWidth = 11;
        ctx.shadowColor = 'rgba(100,190,255,0.75)';
        ctx.shadowBlur = 18;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // 3 — Thin bright core with depth gradient
        const pCam = pts[STEPS];
        const pHor = pts[0];
        const g = ctx.createLinearGradient(pCam.x, pCam.y, pHor.x, pHor.y);
        g.addColorStop(0, 'rgba(210,240,255,0.96)');
        g.addColorStop(0.20, 'rgba(120,195,255,0.88)');
        g.addColorStop(0.55, 'rgba(55,135,255,0.60)');
        g.addColorStop(0.85, 'rgba(20,70,230,0.30)');
        g.addColorStop(1, 'rgba(8,30,180,0.08)');

        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i <= STEPS; i++) ctx.lineTo(pts[i].x, pts[i].y);
        ctx.strokeStyle = g;
        ctx.lineWidth = 2.8;
        ctx.shadowColor = 'rgba(180,225,255,0.95)';
        ctx.shadowBlur = 9;
        ctx.stroke();
        ctx.shadowBlur = 0;

        // 4 — Hair-thin white highlight
        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);
        for (let i = 1; i <= STEPS; i++) ctx.lineTo(pts[i].x, pts[i].y);
        ctx.strokeStyle = 'rgba(255,255,255,0.18)';
        ctx.lineWidth = 0.8;
        ctx.stroke();
      });
    };

    const N_TIES = 35;
    const TIE_SPD = 0.22;
    let tiePhase = 0;

    const drawSleepers = () => {
      for (let i = 0; i < N_TIES; i++) {
        const pos = (i / N_TIES + tiePhase) % 1.0;
        if (pos < 0.005 || pos > 0.998) continue;

        const ptL = trackPt(pos, -0.82);
        const ptR = trackPt(pos, 0.82);

        const alpha = Math.pow(pos, 0.6) * 0.75;
        const lw = Math.max(0.5, pos * 7);

        ctx.beginPath();
        ctx.moveTo(ptL.x, ptL.y);
        ctx.lineTo(ptR.x, ptR.y);
        ctx.strokeStyle = `rgba(20,55,180,${alpha * 0.85})`;
        ctx.lineWidth = lw;
        ctx.shadowColor = `rgba(40,100,255,${alpha * 0.35})`;
        ctx.shadowBlur = 3;
        ctx.stroke();
        ctx.shadowBlur = 0;

        if (pos > 0.18) {
          ctx.beginPath();
          ctx.moveTo(ptL.x, ptL.y - lw * 0.3);
          ctx.lineTo(ptR.x, ptR.y - lw * 0.3);
          ctx.strokeStyle = `rgba(100,170,255,${alpha * 0.25})`;
          ctx.lineWidth = lw * 0.25;
          ctx.stroke();
        }
      }
    };

    const drawBed = () => {
      const STEPS = 80;
      const ptsL = [], ptsR = [];
      for (let i = 0; i <= STEPS; i++) {
        const pos = i / STEPS;
        ptsL.push(trackPt(pos, -0.82));
        ptsR.push(trackPt(pos, 0.82));
      }

      ctx.beginPath();
      ctx.moveTo(ptsL[0].x, ptsL[0].y);
      for (let i = 1; i <= STEPS; i++) ctx.lineTo(ptsL[i].x, ptsL[i].y);
      for (let i = STEPS; i >= 0; i--) ctx.lineTo(ptsR[i].x, ptsR[i].y);
      ctx.closePath();

      const vp = vpPos();
      const bg = ctx.createLinearGradient(W * 0.5, vp.y, W * 0.5, H);
      bg.addColorStop(0, 'rgba(5,20,80,0.0)');
      bg.addColorStop(0.35, 'rgba(5,15,60,0.18)');
      bg.addColorStop(1, 'rgba(3,10,40,0.32)');
      ctx.fillStyle = bg;
      ctx.fill();
    };

    const STARS = Array.from({ length: 90 }, () => ({
      x: Math.random(),
      y: Math.random() * (HY_FRAC - 0.02),
      r: 0.25 + Math.random() * 1.1,
      a: 0.08 + Math.random() * 0.42,
      ph: Math.random() * Math.PI * 2,
      fr: 0.4 + Math.random() * 1.8,
    }));

    const drawStars = () => {
      STARS.forEach(s => {
        const a = s.a * (0.65 + 0.35 * Math.sin(elapsed * s.fr + s.ph));
        ctx.beginPath();
        ctx.arc(s.x * W, s.y * H, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(180,215,255,${a})`;
        ctx.shadowColor = 'rgba(140,190,255,0.5)';
        ctx.shadowBlur = 4;
        ctx.fill();
        ctx.shadowBlur = 0;
      });
    };

    const drawHorizonGlow = () => {
      const vp = vpPos();
      const rg = ctx.createRadialGradient(vp.x, vp.y, 0, vp.x, vp.y, W * 0.9);
      rg.addColorStop(0, 'rgba(60,150,255,0.65)');
      rg.addColorStop(0.05, 'rgba(35,90,255,0.35)');
      rg.addColorStop(0.18, 'rgba(15,45,200,0.18)');
      rg.addColorStop(0.45, 'rgba(5,15,100,0.08)');
      rg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = rg;
      ctx.fillRect(0, 0, W, H);

      const lg = ctx.createRadialGradient(vp.x, vp.y, 0, vp.x, vp.y, 40);
      lg.addColorStop(0, 'rgba(200,235,255,0.85)');
      lg.addColorStop(0.3, 'rgba(100,190,255,0.40)');
      lg.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = lg;
      ctx.beginPath();
      ctx.arc(vp.x, vp.y, 40, 0, Math.PI * 2);
      ctx.fill();
    };

    const drawFog = () => {
      const horizY = H * HY_FRAC;
      const fg = ctx.createLinearGradient(0, horizY, 0, horizY + (H - horizY) * 0.4);
      fg.addColorStop(0, 'rgba(2,8,40,0.0)');
      fg.addColorStop(1, 'rgba(1,4,20,0.22)');
      ctx.fillStyle = fg;
      ctx.fillRect(0, horizY, W, H - horizY);
    };

    const mkDust = () => ({
      x: Math.random(),
      y: HY_FRAC + Math.random() * 0.18,
      vx: (Math.random() - 0.5) * 0.0014,
      vy: 0.0012 + Math.random() * 0.0028,
      r: 0.4 + Math.random() * 1.1,
      a: 0.08 + Math.random() * 0.25,
    });
    const DUST = Array.from({ length: 32 }, mkDust);

    const drawDust = () => {
      DUST.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.x * W, p.y * H, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(90,165,255,${p.a})`;
        ctx.shadowColor = 'rgba(70,150,255,0.6)';
        ctx.shadowBlur = 5;
        ctx.fill();
        ctx.shadowBlur = 0;
        p.x += p.vx; p.y += p.vy;
        if (p.y > HY_FRAC + 0.22 || p.x < -0.02 || p.x > 1.02) {
          Object.assign(p, mkDust());
        }
      });
    };

    const mkSpark = () => {
      const side = Math.random() < 0.5 ? -0.82 : 0.82;
      return {
        side,
        pos: Math.random() * 0.4,
        spd: 0.25 + Math.random() * 0.55,
        a: 0.4 + Math.random() * 0.55,
      };
    };
    const SPARKS = Array.from({ length: 12 }, mkSpark);

    const drawSparks = () => {
      SPARKS.forEach(s => {
        const pt = trackPt(s.pos, s.side);
        const r = Math.max(0.6, s.pos * 4);
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(180,230,255,${s.a * s.pos})`;
        ctx.shadowColor = 'rgba(120,200,255,0.9)';
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.shadowBlur = 0;

        s.pos += s.spd * 0.016;
        if (s.pos > 1.0) Object.assign(s, mkSpark());
      });
    };

    const drawVignette = () => {
      const vg = ctx.createRadialGradient(W * 0.5, H * 0.5, W * 0.2, W * 0.5, H * 0.5, W * 0.95);
      vg.addColorStop(0, 'rgba(0,0,0,0)');
      vg.addColorStop(1, 'rgba(0,0,20,0.85)');
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);
    };

    const render = (now) => {
      const dt = Math.min((now - lastT) / 1000, 0.05);
      lastT = now;
      elapsed += dt;

      tiePhase = (tiePhase + dt * TIE_SPD) % 1.0;

      ctx.fillStyle = '#010610';
      ctx.fillRect(0, 0, W, H);

      drawStars();
      drawHorizonGlow();
      drawFog();
      drawBed();
      drawSleepers();
      drawRails();
      drawSparks();
      drawDust();
      drawVignette();

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame((t) => {
      lastT = t;
      requestAnimationFrame(render);
    });

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <section id="hero">
      <div className="hero-left">
        <p className="h-tag">⭐ TECHNOLOGIES</p>
        <h1
          className="h-head"
          ref={typedHeadRef}
          aria-label="Empowering ambitious professionals with world-class career opportunities."
        ></h1>
        {/* We need the cursor outside the main heading render if we do innerHTML replacement, 
            but for the script, it appends the cursor to the H1 itself. We provide a hidden template cursor to be cloned, or let the script create it. The script creates it. */}
        <span ref={cursorRef} className="typed-cursor" style={{ display: 'none' }}></span>

        <div className="h-btns">
          <a href="#demanded" className="btn-w" id="hero-explore">
            Get Started
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path
                d="M7 17 17 7M9 7h8v8"
                stroke="currentColor"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="1.8"
              />
            </svg>
          </a>
          <a href="#services" className="btn-g" id="hero-quote">
            Our Services
          </a>
        </div>
      </div>

      <div className="hero-right">
        <canvas id="rail-canvas" ref={canvasRef}></canvas>
        <div className="veil"></div>
      </div>
    </section>
  );
};

export default Hero;
